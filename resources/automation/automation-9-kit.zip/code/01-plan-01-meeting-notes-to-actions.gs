// PLAN-01 · 회의록 → 액션아이템 자동 정리
// 난이도 ★ · 예상 30분 · 전제: 구글 계정 + Gemini API 키
// 출처: https://www.nedabah.org/resources/automation/planning/01-meeting-notes-to-actions.html
// Apps Script 편집기에 붙여넣은 뒤 스크립트 속성에 PROPS 항목을 등록하세요.

/**
 * 회의록 → 액션아이템 자동 정리
 * 사용: Google Docs에서 메뉴 [자동화 → 액션아이템 추출] 클릭
 */

const PROPS = PropertiesService.getScriptProperties();
const GEMINI_KEY = PROPS.getProperty('GEMINI_API_KEY');
const SHEET_ID   = PROPS.getProperty('SHEET_ID');
const SLACK_HOOK = PROPS.getProperty('SLACK_WEBHOOK') || '';

function onOpen() {
  DocumentApp.getUi()
    .createMenu('🤖 자동화')
    .addItem('액션아이템 추출', 'extractActions')
    .addToUi();
}

function extractActions() {
  const doc  = DocumentApp.getActiveDocument();
  const text = doc.getBody().getText();
  const url  = doc.getUrl();

  const ui = DocumentApp.getUi();
  ui.alert('처리 중', 'AI가 회의록을 분석합니다. 10~20초 소요됩니다.', ui.ButtonSet.OK);

  const result = callGemini(text);
  appendToSheet(result, url);
  if (SLACK_HOOK) postToSlack(result, url);

  ui.alert('완료', `${result.actions.length}개 액션아이템을 시트에 적재했습니다.`, ui.ButtonSet.OK);
}

function callGemini(meetingText) {
  const prompt = `
다음 회의록에서 정보를 추출하세요. JSON만 반환하세요(설명 없이).

회의록:
"""
${meetingText.slice(0, 30000)}
"""

JSON 스키마:
{
  "meetingName": "회의명",
  "meetingDate": "YYYY-MM-DD",
  "decisions": ["결정사항1", "결정사항2"],
  "actions": [
    {"task":"액션내용","owner":"담당자","due":"YYYY-MM-DD 또는 빈문자열"}
  ]
}

규칙:
- 담당자는 회의록에 등장한 사람만 사용. 추정 금지.
- 기한이 명시되지 않으면 빈문자열.
- 결정사항과 액션아이템은 다르다(결정=합의, 액션=실행).
`;

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`;
  const res = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({
      contents: [{parts: [{text: prompt}]}],
      generationConfig: {responseMimeType: 'application/json'}
    })
  });
  const json = JSON.parse(res.getContentText());
  const content = json.candidates[0].content.parts[0].text;
  return JSON.parse(content);
}

function appendToSheet(result, docUrl) {
  const sheet = SpreadsheetApp.openById(SHEET_ID).getSheets()[0];
  const decisionsStr = result.decisions.join(' | ');
  result.actions.forEach(a => {
    sheet.appendRow([
      result.meetingDate || new Date().toISOString().slice(0,10),
      result.meetingName || '',
      decisionsStr,
      a.task,
      a.owner || '',
      a.due || '',
      '대기',
      docUrl
    ]);
  });
}

function postToSlack(result, docUrl) {
  const lines = result.actions.map((a,i) =>
    `${i+1}. *${a.task}* — ${a.owner || '미지정'}${a.due ? ` (~${a.due})` : ''}`
  ).join('\n');
  const text = `📝 *${result.meetingName}* 회의 요약\n\n*결정사항*\n• ${result.decisions.join('\n• ')}\n\n*액션아이템*\n${lines}\n\n🔗 ${docUrl}`;
  UrlFetchApp.fetch(SLACK_HOOK, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({text})
  });
}