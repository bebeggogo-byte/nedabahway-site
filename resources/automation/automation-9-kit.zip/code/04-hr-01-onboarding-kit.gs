// HR-01 · 신규 입사자 온보딩 키트
// 난이도 ★★ · 예상 60분 · 전제: 구글 Workspace + Docs 템플릿 2개 + (선택) Slack
// 출처: https://www.nedabah.org/resources/automation/hr/01-onboarding-kit.html
// Apps Script 편집기에 붙여넣은 뒤 스크립트 속성에 PROPS 항목을 등록하세요.

const PROPS = PropertiesService.getScriptProperties();
const SHEET_ID  = PROPS.getProperty('MASTER_SHEET_ID');
const TPL_WEL   = PROPS.getProperty('WELCOME_TEMPLATE_ID');
const TPL_CHK   = PROPS.getProperty('CHECKLIST_TEMPLATE_ID');
const FOLDER    = PROPS.getProperty('OUTPUT_FOLDER_ID');
const SLACK     = PROPS.getProperty('SLACK_HOOK') || '';
const FROM_NAME = PROPS.getProperty('HR_FROM_NAME') || 'HR팀';

/**
 * 셋업 시 1회 실행: 설치형 onEdit 트리거를 등록한다.
 * 단순 트리거(onEdit)는 외부 서비스 권한이 없어 메일/캘린더/Drive 호출이 실패한다.
 */
function installTrigger() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  // 기존 동일 트리거가 있으면 제거 (중복 방지)
  ScriptApp.getProjectTriggers()
    .filter(t => t.getHandlerFunction() === 'onEditInstallable')
    .forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('onEditInstallable').forSpreadsheet(ss).onEdit().create();
  Logger.log('설치형 onEdit 트리거 등록 완료');
}

function onEditInstallable(e) {
  const sheet = e.source.getActiveSheet();
  if (sheet.getName() !== 'hires') return;
  const row = e.range.getRow();
  if (row === 1) return;

  const data = sheet.getRange(row, 1, 1, 8).getValues()[0];
  const [name, email, joinDate, dept, role, mentor, mentorEmail, status] = data;
  if (status === '완료' || !name || !email || !joinDate) return;

  // 1) 환영 레터 + 체크리스트 Doc 생성
  const welcomeDoc = copyAndFill(TPL_WEL, `[환영] ${name} 님 - ${fmt(joinDate)}`, {
    이름: name, 입사일: fmt(joinDate), 부서: dept, 직책: role, 멘토: mentor || '추후 안내'
  });
  const checklistDoc = copyAndFill(TPL_CHK, `[체크리스트] ${name} 90일 플랜`, {
    이름: name, 입사일: fmt(joinDate), 부서: dept, 멘토: mentor || ''
  });

  // 2) 환영 메일 (입사자 + 멘토 cc)
  const body = buildWelcomeBody(name, joinDate, dept, role, mentor, welcomeDoc.url, checklistDoc.url);
  GmailApp.sendEmail(email, `${name} 님, ${fmt(joinDate)} 입사를 환영합니다`, body, {
    name: FROM_NAME,
    cc: mentorEmail || '',
    htmlBody: body
  });

  // 3) 캘린더 — Day 1 환영미팅 + Day 7·30·90 체크인 자동 생성
  const cal = CalendarApp.getDefaultCalendar();
  const join = new Date(joinDate);
  cal.createEvent(`${name} 환영 미팅`, atHour(join, 10), atHour(join, 11), {guests: `${email},${mentorEmail||''}`});
  [7, 30, 90].forEach(d => {
    const day = addDays(join, d);
    cal.createEvent(`${name} ${d}일 체크인`, atHour(day, 14), atHour(day, 14, 30), {guests: `${email},${mentorEmail||''}`});
  });

  // 4) 슬랙 공지
  if (SLACK) {
    UrlFetchApp.fetch(SLACK, {
      method: 'post', contentType: 'application/json',
      payload: JSON.stringify({text:
        `🎉 *신규 입사 안내* \n*${name}* 님이 ${fmt(joinDate)} *${dept}/${role}* 으로 합류합니다.\n멘토: ${mentor||'미정'}\n환영 한 마디 남겨주세요.`
      })
    });
  }

  // 5) 상태 업데이트
  sheet.getRange(row, 8).setValue('완료');
  sheet.getRange(row, 9).setValue(welcomeDoc.url);
  sheet.getRange(row, 10).setValue(checklistDoc.url);
}

function copyAndFill(templateId, title, vars) {
  const folder = DriveApp.getFolderById(FOLDER);
  const file = DriveApp.getFileById(templateId).makeCopy(title, folder);
  const doc = DocumentApp.openById(file.getId());
  const body = doc.getBody();
  for (const k in vars) {
    body.replaceText(`{{${k}}}`, String(vars[k]));
  }
  doc.saveAndClose();
  return {id: file.getId(), url: file.getUrl()};
}

function buildWelcomeBody(name, joinDate, dept, role, mentor, welcomeUrl, checklistUrl) {
  return `<div style="font-family:'Noto Sans KR',sans-serif;line-height:1.7;max-width:620px;">
    <h2 style="color:#b45309;">${name} 님, 환영합니다 🎉</h2>
    <p>${fmt(joinDate)} ${dept}/${role}로 입사하시는 ${name} 님께 첫날을 위한 안내를 드립니다.</p>
    <ul>
      <li>📄 <a href="${welcomeUrl}">환영 레터(개인 맞춤)</a></li>
      <li>✅ <a href="${checklistUrl}">90일 온보딩 체크리스트</a></li>
      <li>👥 멘토: ${mentor || '추후 배정'}</li>
      <li>🗓️ 첫날 10:00 환영 미팅이 캘린더에 등록되었습니다.</li>
    </ul>
    <p>입사 전 궁금한 점은 언제든 회신주세요. 좋은 인연이 되길 기대합니다.</p>
    <p style="color:#6a604f;">— ${FROM_NAME}</p>
  </div>`;
}

function fmt(d) { return new Date(d).toISOString().slice(0,10); }
function atHour(d, h, m=0) { const x = new Date(d); x.setHours(h,m,0,0); return x; }
function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate()+n); return x; }