// HR-02 · 휴가 신청 슬랙 승인 워크플로우
// 난이도 ★★★ · 예상 90분 · 전제: Slack App(Bot Token) + Form + 팀장 Slack ID 매핑
// 출처: https://www.nedabah.org/resources/automation/hr/02-leave-approval-workflow.html
// Apps Script 편집기에 붙여넣은 뒤 스크립트 속성에 PROPS 항목을 등록하세요.

function verifySlackSignature(e) {
  const secret = PROPS.getProperty('SLACK_SIGNING_SECRET');
  if (!secret) return true; // 셋업 안 했으면 검증 생략 (개발용)
  const ts  = e.parameter['X-Slack-Request-Timestamp'] || e.headers && e.headers['X-Slack-Request-Timestamp'];
  const sig = e.parameter['X-Slack-Signature']         || e.headers && e.headers['X-Slack-Signature'];
  if (!ts || !sig) return false;
  // 5분 이상 지난 요청은 재전송 공격 가능성으로 거부
  if (Math.abs(Date.now()/1000 - Number(ts)) > 300) return false;
  const base = `v0:${ts}:${e.postData && e.postData.contents || ''}`;
  const mac  = Utilities.computeHmacSha256Signature(base, secret)
    .map(b => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
  return `v0=${mac}` === sig;
}