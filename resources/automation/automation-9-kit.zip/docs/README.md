# 조직 자동화 9선 — 자료 키트

워크숍·강의·자체 학습용 한 번에 받는 패키지입니다. 모든 파일은 무료이며 자기 조직 적용을 위해 자유롭게 수정·사용할 수 있습니다.

## 포함 내용

### code/ — 9개 Apps Script 코드 (`.gs`)
- `1-01-meeting-notes-to-actions.gs` — 회의록 → 액션아이템 자동 정리 (난이도 ★, 예상 30분)
- `2-02-competitor-news-digest.gs` — 경쟁사·뉴스 일일 다이제스트 (난이도 ★★, 예상 45분)
- `3-03-weekly-kpi-report.gs` — 주간 KPI 자동 리포트 (난이도 ★★, 예상 60분)
- `4-01-onboarding-kit.gs` — 신규 입사자 온보딩 키트 (난이도 ★★, 예상 60분)
- `5-02-leave-approval-workflow.gs` — 휴가 신청 슬랙 승인 워크플로우 (난이도 ★★★, 예상 90분)
- `6-03-pulse-survey-sentiment.gs` — 분기 펄스서베이 + AI 감성 분석 (난이도 ★★, 예상 45분)
- `7-01-content-calendar-generator.gs` — 30일 콘텐츠 캘린더 자동 생성 (난이도 ★, 예상 30분)
- `8-02-lead-scoring-router.gs` — 인입 리드 자동 스코어링·배정 (난이도 ★★, 예상 60분)
- `9-03-review-mention-digest.gs` — 리뷰·멘션 주간 다이제스트 (난이도 ★★, 예상 45분)

### docs/
- `automation-9-workbook.pdf` — 9선 통합 워크북 (인쇄·이북 친화)
- `README.md` — 본 파일

## 빠르게 시작하는 법

1. 가장 자주 잃는 시간을 1개 고른다 (`code/`의 첫 번째 `.gs` 또는 워크북의 추천 3선 중)
2. 해당 파일을 Google Apps Script 편집기에 붙여넣고 스크립트 속성에 API 키만 등록
3. 트리거를 1회 실행해 권한을 부여하고 운영 시작
4. 1주일 운영 결과를 본 뒤 두 번째 자동화로 확장

상세 셋업 가이드는 워크북 PDF의 각 챕터 또는 온라인:
- 자료 허브: https://www.nedabah.org/auto
- 용어집: https://www.nedabah.org/resources/automation/glossary.html

## 안전·윤리 기본선

- 익명 설문·VOC 분석에서 **식별 정보(이름·이메일·부서)를 AI에 전송하지 않는다**
- 자동 응답·자동 발송은 **사람 검토 단계**를 한 번 이상 둔다
- API 키는 코드에 직접 쓰지 않고 **Apps Script 스크립트 속성**에 저장한다
- 외부 발송 자동화는 **되돌릴 수 없는 행위**임을 인지한다

## 라이선스

본 자료는 강의 수강자 및 자기 조직 적용을 위해 자유롭게 사용·수정할 수 있습니다. 외부 강의·교재 재배포 시 출처 표기를 부탁드립니다.

— 김창환 · 네다바웨이 · nedabah.way@gmail.com
